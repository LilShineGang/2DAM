package ies.pedro.utils;

import javafx.geometry.Rectangle2D;

import java.util.HashMap;
import java.util.Map;

public class BlocksData {
    public String path;
    public Map<String, HashMap<String, Rectangle2D>> blocks;
}