package ies.pedro.utils;

public @interface XmlAccessoryType {

}
